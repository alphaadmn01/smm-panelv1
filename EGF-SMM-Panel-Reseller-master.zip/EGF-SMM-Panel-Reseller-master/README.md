**

## Easy Grow Fast - SMM Panel Child

*SMM = Social Media Marketing.*

> What is this code?

 + Sell  Followers, Views and Much more using API From [easygrowfast.com](https://easygrowfast.com). OR others Panels.

## Do you wanna try?

*Access: http://child.easygrowfast.com*

    Email: admin@admin.com
    Password: adminadmin

## How to install?
**First:**

    Upload smm Folder with public_html like this 👇

![enter image description here](https://easygrowfast.com/public.png)

**Second:**

    Create a database and upload database.sql from database > database.sql
Third:

    Go to smm > config > database.php and setup your database. 👇
![enter image description here](https://easygrowfast.com/database.png)

*Now go to your domain and Start Using.*

**

## USAGE POLICY

**

> You can use this script to resell SMM Services using API's
> 
You don't have to use [easygrowfast.com](https://easygrowfast.com) API's you can choose your better option.
