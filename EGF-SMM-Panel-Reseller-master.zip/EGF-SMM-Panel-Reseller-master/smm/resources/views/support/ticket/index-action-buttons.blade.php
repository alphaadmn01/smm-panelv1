<a href="{{ url('/support/ticket/'.$id) }}"
   class="btn btn-xs btn-inverse">
    <span class="fui-eye"></span>
</a>