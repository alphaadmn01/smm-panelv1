<?php

return [

    'login' => 'Login',
    'update' => 'Update',
    'create_new' => 'Create New',
    'create' => 'Create',
    'send' => 'Send',
    'proceed' => 'Proceed',
    'pay' => 'Pay',
    'new_order' => 'New Order',
    'see_packages' => 'See Packages',
    'place_order' => 'Place Order',
    'create_new_ticket' => 'Create New Ticket',
    'register' => 'Register',
    'generate' => 'Generate',
    'send_password_reset' => 'Send Password Reset Link',
    'reset_password' => 'Reset Password',
    'add_new' => 'Add New',
    'order_now' => 'Order Now',
    'get_status' => 'Get Status',
    'regenerate' => 'Regenerate',
    'add' => 'Add',
    'change_reseller' => 'Change Reseller',
];
