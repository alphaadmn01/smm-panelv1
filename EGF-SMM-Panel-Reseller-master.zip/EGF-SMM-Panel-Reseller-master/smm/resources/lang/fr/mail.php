<?php
return [
    'ticket_submitted_subject' => 'Un nouveau ticket de support est créé.',
    'ticket_message_subject' => 'Vous avez reçu un nouveau message.',
    'message' => 'Message',
    'description' => 'La description',
    'subject' => 'Assujettir',
    'ticket_id' => 'ID de billets',
    'user' => 'Utilisateur',
    'system_status_report' => 'Rapport d\'état du système',
    'orders' => 'Ordres',
    'tickets' => 'Des billets',
    'users' => 'Utilisateurs',
    'new' => 'Nouveau',
    'total' => 'Total',
    'today' => 'Aujourd\'hui',
    'this_month' => 'Ce mois-ci',
    'lifetime' => 'Durée de vie',

];