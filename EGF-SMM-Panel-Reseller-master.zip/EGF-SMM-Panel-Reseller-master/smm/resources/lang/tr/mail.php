<?php
return [
    'ticket_submitted_subject' => 'Yeni bir destek bileti oluşturuldu.',
    'ticket_message_subject' => 'Yeni bir mesaj aldınız.',
    'message' => 'Mesaj',
    'description' => 'Açıklama',
    'subject' => 'konu',
    'ticket_id' => 'Bilet Kimliği',
    'user' => 'kullanıcı',
    'system_status_report' => 'Sistem Durum Raporu',
    'orders' => 'Emirler',
    'tickets' => 'Biletler',
    'users' => 'Kullanıcılar',
    'new' => 'Yeni',
    'total' => 'Genel Toplam',
    'today' => 'Bugün',
    'this_month' => 'Bu ay',
    'lifetime' => 'Ömür',

];