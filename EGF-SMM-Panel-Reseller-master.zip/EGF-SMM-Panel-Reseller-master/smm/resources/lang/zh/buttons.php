<?php

return [

    'login' => '登录',
    'update' => '更新',
    'create_new' => '创建新的',
    'create' => '创建',
    'send' => '发送',
    'proceed' => '继续',
    'pay' => '支付',
    'new_order' => '新订单',
    'see_packages' => '查看套餐',
    'place_order' => '下订单',
    'create_new_ticket' => '联系客服',
    'register' => '注册',
    'generate' => '生成',
    'send_password_reset' => '发送密码重置链接',
    'reset_password' => '重设密码',
    'add_new' => '添新',
    'order_now' => '现在下单',
    'get_status' => '获取状态',
    'regenerate' => '再生',
    'add' => '增加',
    'change_reseller' => '更改经销商',

];
